# InteriorWebsite
Static Website for Interior Decorator company

This is a static template and it contains some essential services which is needed for any Interior decorator.
If User go to the service page, user should do enquiry for perticular service from that page.


